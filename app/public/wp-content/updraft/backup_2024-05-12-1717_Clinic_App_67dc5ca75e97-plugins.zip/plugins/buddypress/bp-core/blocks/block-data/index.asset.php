<?php return array('dependencies' => array('lodash', 'wp-api-fetch', 'wp-data'), 'version' => 'cdcd49ec346d176e4834');
