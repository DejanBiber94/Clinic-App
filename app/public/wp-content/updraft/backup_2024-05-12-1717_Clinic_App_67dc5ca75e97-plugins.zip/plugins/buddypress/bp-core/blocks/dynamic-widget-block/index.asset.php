<?php return array('dependencies' => array('lodash', 'wp-url'), 'version' => 'c3f133309411487675f3');
