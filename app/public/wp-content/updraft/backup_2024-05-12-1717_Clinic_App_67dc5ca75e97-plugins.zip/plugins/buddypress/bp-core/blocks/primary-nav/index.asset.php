<?php return array('dependencies' => array('bp-block-data', 'wp-block-editor', 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n', 'wp-server-side-render'), 'version' => 'a9dd1bc40256e969a241');
