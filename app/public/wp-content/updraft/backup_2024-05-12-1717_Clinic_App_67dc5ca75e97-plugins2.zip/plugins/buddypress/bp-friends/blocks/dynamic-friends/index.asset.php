<?php return array('dependencies' => array('bp-block-data', 'wp-block-editor', 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n', 'wp-server-side-render'), 'version' => '531955e34225e0bc6b2c');
