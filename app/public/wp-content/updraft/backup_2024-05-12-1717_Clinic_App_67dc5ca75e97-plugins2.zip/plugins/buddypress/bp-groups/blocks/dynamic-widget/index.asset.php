<?php return array('dependencies' => array('bp-dynamic-widget-block', 'wp-escape-html', 'wp-i18n'), 'version' => 'b97a299ba70aa84f1d54');
