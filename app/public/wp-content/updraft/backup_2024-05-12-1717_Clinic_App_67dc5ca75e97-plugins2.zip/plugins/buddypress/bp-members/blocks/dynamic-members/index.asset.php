<?php return array('dependencies' => array('bp-block-data', 'wp-block-editor', 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n', 'wp-server-side-render'), 'version' => '14cc06973ae0bc413685');
