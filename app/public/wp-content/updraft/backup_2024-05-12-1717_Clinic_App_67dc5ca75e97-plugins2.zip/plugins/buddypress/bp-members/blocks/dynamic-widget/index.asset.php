<?php return array('dependencies' => array('bp-dynamic-widget-block', 'wp-escape-html', 'wp-i18n'), 'version' => '8936cbebdc61caff43df');
